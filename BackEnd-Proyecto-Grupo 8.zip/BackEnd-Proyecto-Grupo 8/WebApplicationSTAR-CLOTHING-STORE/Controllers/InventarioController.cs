﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventarioController : ControllerBase
    {
        private readonly IRepositorioInventario _repositorioInventario;
        public InventarioController(IRepositorioInventario inventario)
        {
            this._repositorioInventario = inventario;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioInventario.ObtenerInventario();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Inventario inventario)
        {
            try
            {

                await _repositorioInventario.AgregarInventario(inventario);
                return CreatedAtAction("Get", new { id = inventario.InventarioId }, inventario);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /* [HttpGet("{id}")]
         public async Task<IActionResult> Get(int id)
         {
             try
             {
                 var persona = await _repositorioCatalogo.ObtenerPorId(id);
                 return Ok(persona);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.ToString());
             }
         }

         [HttpDelete("{id}")]
         public async Task<IActionResult> Delete(int id)
         {
             try
             {
                 await _repositorioCatalogo.EliminarCatalogo(id);
                 return NoContent();
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }
         }
         [HttpPut("{id}")]
         public async Task<IActionResult> Put(Catalogo catalogo)
         {
             try
             {
                 await _repositorioCatalogo.ModificarCatalogo(catalogo);
                 return Ok(catalogo.CatalogoId);
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }

         }*/
    }
}
