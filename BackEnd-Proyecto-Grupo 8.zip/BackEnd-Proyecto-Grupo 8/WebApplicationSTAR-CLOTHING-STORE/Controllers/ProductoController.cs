﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IRepositorioProductos _repositorioProducto;
        public ProductoController(IRepositorioProductos producto)
        {
            this._repositorioProducto = producto;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioProducto.ObtenerProducto();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(
    [FromForm] string nombreProducto,
    [FromForm] int cantidad,
    [FromForm] decimal precio,
    [FromForm] string categoria,
    [FromForm] string descripcion,
    [FromForm] int proveedorId,
    [FromForm] string imagenProducto) // Base64 image string
        {
            try
            {

                var producto = new Producto
                {
                    nombreProducto = nombreProducto,
                    cantidad = cantidad,
                    precio = precio,
                    categoria = categoria,
                    descripcion = descripcion,
                    proveedorId = proveedorId,
                   imagenProducto = imagenProducto 
                };

                await _repositorioProducto.AgregarProducto(producto);
                return CreatedAtAction("Get", new { id = producto.ProductoId }, producto);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("producto/{id}/imagen")]
        public async Task<IActionResult> GetImagen(int id)
        {
            var producto = await _repositorioProducto.ObtenerProductoPorId(id);
            if (producto == null)
            {
                return NotFound();
            }

            return Ok(producto.imagenProducto);
        }




        [HttpGet("categoria/{categoria}")]
        public async Task<IActionResult> GetByCategoria(string categoria)
        {
            try
            {
                var productos = await _repositorioProducto.ObtenerProductosPorCategoria(categoria);
                return Ok(productos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Producto cliente)
        {
            try
            {
                await _repositorioProducto.ModificarProducto(cliente);
                return Ok(cliente.ProductoId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var cliente = await _repositorioProducto.ObtenerClientePorId(id);

            if (cliente == null)
            {
                return NotFound($"Cliente con ID {id} no encontrado.");
            }

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioProducto.EliminarProducto(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
    }
}
