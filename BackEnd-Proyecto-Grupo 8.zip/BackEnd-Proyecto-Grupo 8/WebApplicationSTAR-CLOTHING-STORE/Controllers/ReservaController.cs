﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservaController : ControllerBase
    {
        private readonly IRepositorioReservacion _repositorioReserva;
        public ReservaController(IRepositorioReservacion reserva)
        {
            this._repositorioReserva = reserva;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioReserva.ObtenerReserva();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Reserva reserva)
        {
            try
            {

                await _repositorioReserva.AgregarReserva(reserva);
                return CreatedAtAction("Get", new { id = reserva.ReservaId }, reserva);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("codigo/{codigo}")]
        public async Task<ActionResult<Reserva>> ObtenerReservaPorCodigo(int codigo)
        {
            var reserva = await _repositorioReserva.ObtenerReservaPorCodigo(codigo);

            if (reserva == null)
            {
                return NotFound();
            }

            return Ok(reserva);
        }



        /* [HttpGet("{id}")]
         public async Task<IActionResult> Get(int id)
         {
             try
             {
                 var persona = await _repositorioCatalogo.ObtenerPorId(id);
                 return Ok(persona);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.ToString());
             }
         }

         [HttpDelete("{id}")]
         public async Task<IActionResult> Delete(int id)
         {
             try
             {
                 await _repositorioCatalogo.EliminarCatalogo(id);
                 return NoContent();
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }
         }
         [HttpPut("{id}")]
         public async Task<IActionResult> Put(Catalogo catalogo)
         {
             try
             {
                 await _repositorioCatalogo.ModificarCatalogo(catalogo);
                 return Ok(catalogo.CatalogoId);
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }

         }*/
    }
}
