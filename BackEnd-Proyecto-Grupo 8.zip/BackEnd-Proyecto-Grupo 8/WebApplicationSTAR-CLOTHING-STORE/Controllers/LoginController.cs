﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {

        private readonly IRepositorioLogin _repositorioLogin;

        public LoginController(IRepositorioLogin login)
        {
            _repositorioLogin = login;
        }

        [HttpGet("byCorreo/{correo}/{contrasenia}")]
        public async Task<IActionResult> GetUsuarioByCorreo(string correo, string contrasenia)
        {
            try
            {
                var usuario = await _repositorioLogin.GetUsuarioByCorreo(correo, contrasenia);
                if (usuario != null)
                {
                    return Ok(new
                    {
                        usuario.tipoUsuario,
                        usuario.Cliente,
                        usuario.Proveedor,
                        usuario.EmpresaTransporte
                    });
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}