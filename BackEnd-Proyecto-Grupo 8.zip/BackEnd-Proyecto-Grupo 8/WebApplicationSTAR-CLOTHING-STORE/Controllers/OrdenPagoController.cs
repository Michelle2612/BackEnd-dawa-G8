﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdenPagoController : ControllerBase
    {
        private readonly IRepositorioOrdenPago _repositorioOrdenPago;
        private readonly IRepositorioCliente _clienteRepository;
        private readonly IRepositorioProductos _repositorioProductos;
        public OrdenPagoController(IRepositorioOrdenPago orden, IRepositorioCliente clienteRepository, IRepositorioProductos repositorioProductos)
        {
            _repositorioOrdenPago = orden;
            _clienteRepository = clienteRepository;
            _repositorioProductos = repositorioProductos;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioOrdenPago.ObtenerOrdenPago();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Post(OrdenPago orden)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                await _repositorioOrdenPago.AgregarOrdenPago(orden);
                return CreatedAtAction("Get", new { id = orden.OrdenPagoId }, orden);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al agregar la orden de pago: {ex.Message}");
            }
        }
        [HttpGet("codigo/{codigo}")]
        public async Task<ActionResult<object>> GetOrdenPagoByCodigo(int codigo)
        {
             var ordenPago = await _repositorioOrdenPago.ObtenerReservaPorCodigo(codigo);

                if (ordenPago == null)
                {
                    return NotFound();
                }

                var cliente = await _repositorioOrdenPago.ObtenerClientePorId(ordenPago.clienteId);

                var result = new
                {
                    OrdenPago = ordenPago,
                    Cliente = cliente
                };

                return Ok(result);

        }

        [HttpGet("Clientes/{clienteId}")]
        public async Task<IActionResult> GetProductosByCliente(string clienteId)
        {
            var productos = await _repositorioOrdenPago.GetProductosByClienteAsync(clienteId);
            if (productos == null || !productos.Any())
            {
                return NotFound();
            }
            return Ok(productos);

         
        }




        /* [HttpGet("{id}")]
         public async Task<IActionResult> Get(int id)
         {
             try
             {
                 var persona = await _repositorioCatalogo.ObtenerPorId(id);
                 return Ok(persona);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.ToString());
             }
         }

         [HttpDelete("{id}")]
         public async Task<IActionResult> Delete(int id)
         {
             try
             {
                 await _repositorioCatalogo.EliminarCatalogo(id);
                 return NoContent();
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }
         }
         [HttpPut("{id}")]
         public async Task<IActionResult> Put(Catalogo catalogo)
         {
             try
             {
                 await _repositorioCatalogo.ModificarCatalogo(catalogo);
                 return Ok(catalogo.CatalogoId);
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }

         }*/
    }
}
