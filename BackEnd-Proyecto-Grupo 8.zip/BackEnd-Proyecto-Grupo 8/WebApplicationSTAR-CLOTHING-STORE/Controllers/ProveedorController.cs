﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProveedorController : ControllerBase
    {
        private readonly IRepositorioProveedor _repositorioProveedor;
        private readonly IRepositorioLogin _repositorioLogin;
        public ProveedorController(IRepositorioProveedor proveedor, IRepositorioLogin repositorioLogin)
        {
            _repositorioProveedor = proveedor;
            _repositorioLogin = repositorioLogin;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioProveedor.ObtenerProveedor();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Proveedor proveedor)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); 
            }

            try
            {
                
                var login = await _repositorioLogin.RegistrarProveedor(proveedor);
                return CreatedAtAction("Get", new { id = proveedor.ProveedorId }, proveedor);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Proveedor cliente)
        {
            try
            {
                await _repositorioProveedor.ModificarProveedor(cliente);
                return Ok(cliente.ProveedorId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var cliente = await _repositorioProveedor.ObtenerClientePorId(id);

            if (cliente == null)
            {
                return NotFound($"Cliente con ID {id} no encontrado.");
            }

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioProveedor.EliminarProveedor(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
    }
}
