﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly IRepositorioCliente _repositorioCliente;
        private readonly IRepositorioLogin _repositorioLogin;
        public ClienteController(IRepositorioCliente repositorioCliente, IRepositorioLogin repositorioLogin)
        {
            _repositorioCliente = repositorioCliente;
            _repositorioLogin = repositorioLogin;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioCliente.ObtenerCliente();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns details about validation errors
            }

            try
            {
                // Assuming you are not setting the fechaNacimiento to the current date time
                var login = await _repositorioLogin.RegistrarCliente(cliente);
                return CreatedAtAction("Get", new { id = cliente.ClienteId }, cliente);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Cliente cliente)
        {
            try
            {
                await _repositorioCliente.ModificarCliente(cliente);
                return Ok(cliente.ClienteId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var cliente = await _repositorioCliente.ObtenerClientePorId(id);

            if (cliente == null)
            {
                return NotFound($"Cliente con ID {id} no encontrado.");
            }

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioCliente.EliminarCliente(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
        /*[HttpGet("{clienteId}")]
        public async Task<IActionResult> GetClienteById(string clienteId)
        {
            var cliente = await _repositorioCliente.ObtenerClientePorId(clienteId);
            if (cliente == null)
            {
                return NotFound();
            }
            return Ok(cliente);
        }
   

        /* [HttpGet("{id}")]
         public async Task<IActionResult> Get(int id)
         {
             try
             {
                 var persona = await _repositorioCatalogo.ObtenerPorId(id);
                 return Ok(persona);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.ToString());
             }
         }

         [HttpDelete("{id}")]
         public async Task<IActionResult> Delete(int id)
         {
             try
             {
                 await _repositorioCatalogo.EliminarCatalogo(id);
                 return NoContent();
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }
         }
      */
    }
}
