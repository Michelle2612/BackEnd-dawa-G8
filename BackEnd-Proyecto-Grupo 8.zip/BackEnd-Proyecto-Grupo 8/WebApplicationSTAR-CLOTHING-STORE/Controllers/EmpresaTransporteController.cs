﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmpresaTransporteController : ControllerBase
    {
        private readonly IRepositorioEmpresaTransporte _repositorioEmpresa;
        private readonly IRepositorioLogin _repositorioLogin;
        public EmpresaTransporteController(IRepositorioEmpresaTransporte empresa, IRepositorioLogin repositorioLogin)
        {
            _repositorioEmpresa = empresa;
            _repositorioLogin = repositorioLogin;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); 
            }
            try
            {
                var lista = await _repositorioEmpresa.ObtenerEmpresa();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] EmpresaTransporte empresa)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns details about validation errors
            }

            try
            {
                // Assuming you are not setting the fechaNacimiento to the current date time
                var login = await _repositorioLogin.RegistrarEmpresaTransporte(empresa);
                return CreatedAtAction("Get", new { id = empresa.EmpresaTransporteId }, empresa);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(EmpresaTransporte cliente)
        {
            try
            {
                await _repositorioEmpresa.ModificarEmpresa(cliente);
                return Ok(cliente.EmpresaTransporteId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var cliente = await _repositorioEmpresa.ObtenerClientePorId(id);

            if (cliente == null)
            {
                return NotFound($"Cliente con ID {id} no encontrado.");
            }

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioEmpresa.EliminarEmpresa(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
    }
}
