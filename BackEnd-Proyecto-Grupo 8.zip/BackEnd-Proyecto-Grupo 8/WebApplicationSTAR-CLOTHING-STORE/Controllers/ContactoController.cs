﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactoController : ControllerBase
    {
        private readonly IRepositorioContacto _repositorioContacto;
        public ContactoController(IRepositorioContacto contacto)
        {
            this._repositorioContacto = contacto;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioContacto.ObtenerContacto();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(Contacto contacto)
        {
            try
            {

                await _repositorioContacto.AgregarContacto(contacto);
                return CreatedAtAction("Get", new { id = contacto.ContactoId }, contacto);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(Contacto cliente)
        {
            try
            {
                await _repositorioContacto.ModificarContacto(cliente);
                return Ok(cliente.ContactoId);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var cliente = await _repositorioContacto.ObtenerClientePorId(id);

            if (cliente == null)
            {
                return NotFound($"Cliente con ID {id} no encontrado.");
            }

            return Ok(cliente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _repositorioContacto.EliminarContacto(id);
                return NoContent();
            }
            catch (Exception ex)
            {

                return BadRequest(ex.ToString());
            }
        }
    }
}
