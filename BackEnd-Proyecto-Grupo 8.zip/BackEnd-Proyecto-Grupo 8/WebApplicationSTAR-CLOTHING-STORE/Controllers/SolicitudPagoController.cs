﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Repositorio;
using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSTAR_CLOTHING_STORE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SolicitudPagoController : ControllerBase
    {
        private readonly IRepositorioSolicitudOrden _repositorioSolicitud;
        public SolicitudPagoController(IRepositorioSolicitudOrden solicitud)
        {
            this._repositorioSolicitud = solicitud;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lista = await _repositorioSolicitud.ObtenerSolicitud();
                return Ok(lista);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post(SolicitudOrden solicitud)
        {
            try
            {

                await _repositorioSolicitud.AgregarSolicitud(solicitud);
                return CreatedAtAction("Get", new { id = solicitud.SolicitudOrdenId }, solicitud);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("codigo/{codigo}")]
        public async Task<ActionResult<Reserva>> ObtenerReservaPorCodigo(int codigo)
        {
            var reserva = await _repositorioSolicitud.ObtenerReservaPorCodigo(codigo);

            if (reserva == null)
            {
                return NotFound();
            }

            return Ok(reserva);
        }






        /* [HttpGet("{id}")]
         public async Task<IActionResult> Get(int id)
         {
             try
             {
                 var persona = await _repositorioCatalogo.ObtenerPorId(id);
                 return Ok(persona);
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.ToString());
             }
         }

         [HttpDelete("{id}")]
         public async Task<IActionResult> Delete(int id)
         {
             try
             {
                 await _repositorioCatalogo.EliminarCatalogo(id);
                 return NoContent();
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }
         }
         [HttpPut("{id}")]
         public async Task<IActionResult> Put(Catalogo catalogo)
         {
             try
             {
                 await _repositorioCatalogo.ModificarCatalogo(catalogo);
                 return Ok(catalogo.CatalogoId);
             }
             catch (Exception ex)
             {

                 return BadRequest(ex.ToString());
             }

         }*/
    }
}
