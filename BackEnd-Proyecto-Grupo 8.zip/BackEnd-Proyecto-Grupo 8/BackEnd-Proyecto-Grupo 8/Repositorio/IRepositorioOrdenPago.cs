﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using BackEnd_Proyecto_Grupo_8.Migrations;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioOrdenPago
    {
        Task<int> AgregarOrdenPago(OrdenPago ordenPago);
        Task<List<OrdenPago>> ObtenerOrdenPago();
        Task<OrdenPago> ObtenerReservaPorCodigo(int codigo);
        Task<Cliente> ObtenerClientePorId(string clienteId);
   
        Task<List<Producto>> GetProductosByClienteAsync(string clienteId);
      
    }
}
