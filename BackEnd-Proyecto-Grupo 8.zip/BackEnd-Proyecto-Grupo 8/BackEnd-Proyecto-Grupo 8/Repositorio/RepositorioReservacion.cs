﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioReservacion : IRepositorioReservacion
    {
        private readonly ApplicationDbContext context;

        public RepositorioReservacion(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarReserva(Reserva reserva)
        {
            context.Reservaciones.Add(reserva);
            await context.SaveChangesAsync();
            return reserva.ReservaId;
        }

        public async Task<List<Reserva>> ObtenerReserva()
        {
            return await context.Reservaciones.ToListAsync();
        }

        public async Task<Reserva?> ObtenerReservaPorCodigo(int codigo)
        {
            return await context.Reservaciones
                 .FirstOrDefaultAsync(r => r.codigo == codigo);
        }


    }
}
/* return await context.Reservaciones
            .Where(r => r.clienteId == clienteId)
            .ToListAsync();*/

