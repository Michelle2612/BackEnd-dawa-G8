﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioSolicitudOrden
    {
        Task<int> AgregarSolicitud(SolicitudOrden solicitudOrden);
        Task<List<SolicitudOrden>> ObtenerSolicitud();
        Task<SolicitudOrden?> ObtenerReservaPorCodigo(int codigo);
    }
}
