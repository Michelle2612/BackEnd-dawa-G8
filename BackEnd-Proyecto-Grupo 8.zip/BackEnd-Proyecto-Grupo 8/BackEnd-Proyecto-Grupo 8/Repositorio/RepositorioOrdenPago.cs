﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioOrdenPago : IRepositorioOrdenPago
    {
        private readonly ApplicationDbContext context;

        public RepositorioOrdenPago(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarOrdenPago(OrdenPago ordenPago)
        {
            context.OrdenPagos.Add(ordenPago);
            await context.SaveChangesAsync();
            return ordenPago.OrdenPagoId;
        }

        public async Task<List<Producto>> GetProductosByClienteAsync(string clienteId)
        {
            return await context.Productos
               .Where(p => p.nombreProducto == clienteId)
               .ToListAsync();
        }


        public async Task<Cliente> ObtenerClientePorId(string clienteId)
        {
             return await context.Clientes
             .FirstOrDefaultAsync(c => c.nombreCliente == clienteId);
           
        }


        public async Task<List<OrdenPago>> ObtenerOrdenPago()
        {
            return await context.OrdenPagos.ToListAsync();
        }

   

        public async Task<OrdenPago> ObtenerReservaPorCodigo(int codigo)
        {
            return await context.OrdenPagos
            .FirstOrDefaultAsync(o => o.codigo == codigo);
        }
    }
}
