﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioInventario
    {
        Task<int> AgregarInventario(Inventario inventario);
        Task<List<Inventario>> ObtenerInventario();
    }
}
