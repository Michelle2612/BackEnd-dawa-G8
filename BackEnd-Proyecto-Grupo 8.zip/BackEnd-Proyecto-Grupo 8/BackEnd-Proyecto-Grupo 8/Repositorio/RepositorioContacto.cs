﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioContacto : IRepositorioContacto
    {
        private readonly ApplicationDbContext context;

        public RepositorioContacto(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarContacto(Contacto contacto)
        {
            context.Contactos.Add(contacto);
            await context.SaveChangesAsync();
            return contacto.ContactoId;
        }

        public async Task EliminarContacto(int id)
        {
            Contacto persona = await context.Contactos.FindAsync(id);
            context.Contactos.Remove(persona);
            context.SaveChanges();
        }

        public async Task<int> ModificarContacto(Contacto contacto)
        {
            Contacto cli = await context.Contactos.FindAsync(contacto.ContactoId);
            cli.nombre = contacto.nombre;
            cli.correo = contacto.correo;
            cli.asunto = contacto.asunto;
            cli.descripcion = contacto.descripcion;
            
            await context.SaveChangesAsync();
            return cli.ContactoId;
        }

        public async Task<Contacto> ObtenerClientePorId(int contactoId)
        {
            return await context.Contactos.FindAsync(contactoId);
        }

        public async Task<List<Contacto>> ObtenerContacto()
        {
            return await context.Contactos.ToListAsync();
        }
    }
}
