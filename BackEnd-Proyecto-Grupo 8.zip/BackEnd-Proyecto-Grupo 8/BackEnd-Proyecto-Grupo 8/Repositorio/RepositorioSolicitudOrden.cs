﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioSolicitudOrden : IRepositorioSolicitudOrden
    {
        private readonly ApplicationDbContext context;

        public RepositorioSolicitudOrden(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarSolicitud(SolicitudOrden solicitudOrden)
        {
            context.SolicitudOrdenes.Add(solicitudOrden);
            await context.SaveChangesAsync();
            return solicitudOrden.SolicitudOrdenId;
        }

        public async Task<SolicitudOrden> ObtenerReservaPorCodigo(int codigo)
        {
            return await context.SolicitudOrdenes
                  .FirstOrDefaultAsync(r => r.codigo == codigo);
        }

        public async Task<List<SolicitudOrden>> ObtenerSolicitud()
        {
            return await context.SolicitudOrdenes.ToListAsync();
        }
    }
}
