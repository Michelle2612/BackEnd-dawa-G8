﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioCliente : IRepositorioCliente
    {
        private readonly ApplicationDbContext context;

        public RepositorioCliente(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarCliente(Cliente cliente)
        {
            context.Clientes.Add(cliente);
            await context.SaveChangesAsync();
            return cliente.ClienteId;
        }

        public async Task EliminarCliente(int id)
        {
            Cliente persona = await context.Clientes.FindAsync(id);
            context.Clientes.Remove(persona);
            context.SaveChanges();
        }

        public async Task<int> ModificarCliente(Cliente cliente)
        {
            Cliente cli = await context.Clientes.FindAsync(cliente.ClienteId);
            cli.nombreCliente = cliente.nombreCliente;
            cli.apellidoCliente = cliente.apellidoCliente;
            cli.cedula = cliente.cedula;
            cli.genero = cliente.genero;
            cli.contrasenia = cliente.contrasenia;
            cli.correo = cliente.correo;
            cli.direccion = cliente.direccion;
            cli.fecha_nacimiento = cliente.fecha_nacimiento;
            cli.telefono = cliente.telefono;
            await context.SaveChangesAsync();
            return cli.ClienteId;
           
        }

        public async Task<List<Cliente>> ObtenerCliente()
        {
            return await context.Clientes.ToListAsync();
        }

        public async Task<Cliente> ObtenerClientePorId(int clienteId)
        {
            return await context.Clientes.FindAsync(clienteId);
        }

   
    }
}
