﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioReservacion
    {
        Task<int> AgregarReserva(Reserva reserva);
        Task<List<Reserva>> ObtenerReserva();
        Task<Reserva> ObtenerReservaPorCodigo(int codigo);
       
    }
}
