﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioContacto
    {
        Task<int> AgregarContacto(Contacto contacto);
        Task<List<Contacto>> ObtenerContacto();
        Task<Contacto> ObtenerClientePorId(int contactoId);

        Task<int> ModificarContacto(Contacto contacto);
        Task EliminarContacto(int id);
    }
}
