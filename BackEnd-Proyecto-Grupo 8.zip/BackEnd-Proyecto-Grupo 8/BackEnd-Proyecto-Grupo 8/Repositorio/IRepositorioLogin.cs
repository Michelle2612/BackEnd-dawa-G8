﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioLogin
    {
        Task<Login> RegistrarCliente(Cliente cliente);
        Task<Login> RegistrarProveedor(Proveedor proveedor);
        Task<Login> RegistrarEmpresaTransporte(EmpresaTransporte empresaTransporte);
        Task AddLogin(Login login);
        Task<Login> GetUsuarioByCorreo(string correo, string contrasenia);
    }
}
