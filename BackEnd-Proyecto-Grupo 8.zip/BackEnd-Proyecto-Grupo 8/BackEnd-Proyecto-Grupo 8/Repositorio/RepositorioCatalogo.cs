﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioCatalogo : IRepositorioCatalogo
    {
        private readonly ApplicationDbContext context;

        public RepositorioCatalogo(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarCatalogo(Catalogo catalogo)
        {
            context.Catalogos.Add(catalogo);
            await context.SaveChangesAsync();
            return catalogo.CatalogoId;
        }

        public async Task<List<Catalogo>> ObtenerCatalogo()
        {
            return await context.Catalogos.ToListAsync();
        }


        public async Task<List<Catalogo>> ObtenerCatalogoPorCategoria(string categoria)
        {
            return await context.Catalogos
              .Include(c => c.productoId)
              .Where(c => c.producto.categoria == categoria)
              .ToListAsync();
        }
    }
}
