﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioLogin : IRepositorioLogin
    {
        private readonly ApplicationDbContext context;

        public RepositorioLogin(ApplicationDbContext context)
        {
            this.context = context;
        }

        public async Task AddLogin(Login login)
        {
            context.Logins.Add(login);
            await context.SaveChangesAsync();
        }

        public async Task<Login> GetUsuarioByCorreo(string correo, string contrasenia)
        {
            var usuario = await context.Set<Login>()
              .Include(l => l.Cliente)
              .Include(l => l.Proveedor)
              .Include(l => l.EmpresaTransporte)
              .FirstOrDefaultAsync(l => l.usuario == correo && l.contrasenia == contrasenia);

            if (usuario != null)
            {
                if (usuario.Cliente != null)
                {
                    usuario.tipoUsuario = "Cliente";
                }
                else if (usuario.Proveedor != null)
                {
                    usuario.tipoUsuario = "Proveedor";
                }
                else if (usuario.EmpresaTransporte != null)
                {
                    usuario.tipoUsuario = "EmpresaTransporte";
                }
            }
            return usuario;

        }

        public async Task<Login> RegistrarCliente(Cliente cliente)
        {
            var login = new Login
            {
                usuario = cliente.correo,
                contrasenia = cliente.contrasenia,
                
            };

            // Guardar el Login en la base de datos
            context.Logins.Add(login);
            await context.SaveChangesAsync();

            // Asignar el LoginId al Cliente
            cliente.loginId = login.LoginId;

            // Guardar el Cliente en la base de datos
            context.Clientes.Add(cliente);
            await context.SaveChangesAsync();

            return login;
        }

        public async Task<Login> RegistrarEmpresaTransporte(EmpresaTransporte empresaTransporte)
        {
            var login = new Login
            {
                usuario = empresaTransporte.correo,
                contrasenia = empresaTransporte.contrasenia,
                //tipoUsuario = TipoUsuario.EmpresaTransporte
            };

            context.Logins.Add(login);
            await context.SaveChangesAsync();

            empresaTransporte.loginId = login.LoginId;
            context.EmpresaTransportes.Add(empresaTransporte);
            await context.SaveChangesAsync();

            return login;
        }

        public async Task<Login> RegistrarProveedor(Proveedor proveedor)
        {
            var login = new Login
            {
                usuario = proveedor.correo,
                contrasenia = proveedor.contrasenia,
             
            };

            context.Logins.Add(login);
            await context.SaveChangesAsync();

            proveedor.loginId = login.LoginId;
            context.Proveedores.Add(proveedor);
            await context.SaveChangesAsync();

            return login;
        }
    }
}
