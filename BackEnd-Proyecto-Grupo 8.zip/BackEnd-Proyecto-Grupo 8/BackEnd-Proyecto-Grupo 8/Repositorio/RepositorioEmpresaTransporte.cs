﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioEmpresaTransporte : IRepositorioEmpresaTransporte
    {
        private readonly ApplicationDbContext context;

        public RepositorioEmpresaTransporte(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarEmpresa(EmpresaTransporte empresaTransporte)
        {
            context.EmpresaTransportes.Add(empresaTransporte);
            await context.SaveChangesAsync();
            return empresaTransporte.EmpresaTransporteId;
        }

        public async Task EliminarEmpresa(int id)
        {
            EmpresaTransporte persona = await context.EmpresaTransportes.FindAsync(id);
            context.EmpresaTransportes.Remove(persona);
            context.SaveChanges();
        }

        public async Task<int> ModificarEmpresa(EmpresaTransporte contacto)
        {
            EmpresaTransporte cli = await context.EmpresaTransportes.FindAsync(contacto.EmpresaTransporteId);
            cli.num_compania = contacto.num_compania;
            cli.RUC = contacto.RUC;
            cli.nombreEmpresa = contacto.nombreEmpresa;
            cli.correo = contacto.correo;
            cli.contrasenia = contacto.contrasenia;
            cli.telefono = contacto.telefono;
            cli.direccion = contacto.direccion;
      
            await context.SaveChangesAsync();
            return cli.EmpresaTransporteId;
        }

        public async Task<EmpresaTransporte> ObtenerClientePorId(int contactoId)
        {
            return await context.EmpresaTransportes.FindAsync(contactoId);
        }

        public async Task<List<EmpresaTransporte>> ObtenerEmpresa()
        {
            return await context.EmpresaTransportes.ToListAsync();
        }
    }
}
