﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioProductos
    {
        Task<int> AgregarProducto(Producto producto);
        Task<List<Producto>> ObtenerProducto();
        Task<List<Producto>> ObtenerProductosPorCategoria(string categoria);
        Task<Producto> ObtenerProductoPorId(int id);
        Task<List<Producto>> ObtenerProductosPorClienteId(string clienteId);
        Task<Producto> ObtenerClientePorId(int contactoId);

        Task<int> ModificarProducto(Producto contacto);
        Task EliminarProducto(int id);
    }
}
