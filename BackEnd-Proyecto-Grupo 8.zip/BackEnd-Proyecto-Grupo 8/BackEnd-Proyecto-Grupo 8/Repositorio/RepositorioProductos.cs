﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioProductos : IRepositorioProductos
    {
        private readonly ApplicationDbContext context;

        public RepositorioProductos(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarProducto(Producto producto)
        {
            context.Productos.Add(producto);
            await context.SaveChangesAsync();
            return producto.ProductoId;
        }

        public async Task EliminarProducto(int id)
        {
            Producto persona = await context.Productos.FindAsync(id);
            context.Productos.Remove(persona);
            context.SaveChanges();
        }

        public async Task<int> ModificarProducto(Producto contacto)
        {
            Producto cli = await context.Productos.FindAsync(contacto.ProductoId);
            cli.imagenProducto = contacto.imagenProducto;
            cli.nombreProducto = contacto.nombreProducto;
            cli.cantidad = contacto.cantidad;
            cli.descripcion = contacto.descripcion;
            cli.precio = contacto.precio;
            cli.categoria = contacto.categoria;
            cli.descripcion = contacto.descripcion;
            cli.proveedorId = contacto.proveedorId;
            await context.SaveChangesAsync();
            return cli.ProductoId;
        }

        public async Task<Producto> ObtenerClientePorId(int contactoId)
        {
            return await context.Productos.FindAsync(contactoId);
        }

        public async Task<List<Producto>> ObtenerProducto()
        {
            return await context.Productos.ToListAsync();
        }

        public async Task<Producto> ObtenerProductoPorId(int id)
        {
            return await context.Productos.FindAsync(id);
        }

        public async Task<List<Producto>> ObtenerProductosPorCategoria(string categoria)
        {
            return await context.Productos
                .Where(p => p.categoria == categoria)
                .ToListAsync();
        }

   
        public async Task<List<Producto>> ObtenerProductosPorClienteId(string clienteId)
        {
            var ordenesPago = await context.OrdenPagos
           .Where(o => o.clienteId == clienteId)
           .ToListAsync();

            // Filtramos los productos basándonos en las órdenes de pago obtenidas
            var productos = await context.Productos
                .Where(p => ordenesPago.Any(o => o.clienteId == clienteId))
                .ToListAsync();

            return productos;
        }
    }
}
