﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{

    public class RepositorioFactura : IRepositorioFactura
    {
        private readonly ApplicationDbContext context;

        public RepositorioFactura(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarFactura(Factura factura)
        {
            context.Facturas.Add(factura);
            await context.SaveChangesAsync();
            return factura.FacturaId;
        }

        public async Task<List<Factura>> ObtenerFactura()
        {
            return await context.Facturas.ToListAsync();
        }
    }
}
