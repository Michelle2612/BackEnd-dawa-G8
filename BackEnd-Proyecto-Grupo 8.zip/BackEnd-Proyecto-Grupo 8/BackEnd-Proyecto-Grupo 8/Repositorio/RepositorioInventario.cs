﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioInventario : IRepositorioInventario
    {
        private readonly ApplicationDbContext context;

        public RepositorioInventario(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarInventario(Inventario inventario)
        {
            context.Inventarios.Add(inventario);
            await context.SaveChangesAsync();
            return inventario.InventarioId;
        }

        public async Task<List<Inventario>> ObtenerInventario()
        {
            return await context.Inventarios.ToListAsync();
        }
    }
}
