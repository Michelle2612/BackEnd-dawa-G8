﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioEmpresaTransporte
    {
        Task<int> AgregarEmpresa(EmpresaTransporte empresaTransporte);
        Task<List<EmpresaTransporte>> ObtenerEmpresa();
        Task<EmpresaTransporte> ObtenerClientePorId(int contactoId);

        Task<int> ModificarEmpresa(EmpresaTransporte contacto);
        Task EliminarEmpresa(int id);
    }
}
