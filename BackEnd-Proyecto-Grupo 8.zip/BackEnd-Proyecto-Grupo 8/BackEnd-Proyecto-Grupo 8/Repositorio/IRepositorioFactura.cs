﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioFactura
    {
        Task<int> AgregarFactura(Factura factura);
        Task<List<Factura>> ObtenerFactura();
    }
}
