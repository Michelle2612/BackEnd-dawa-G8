﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioProveedor
    {
        Task<int> AgregarProveedor(Proveedor proveedor);
        Task<List<Proveedor>> ObtenerProveedor();
        Task<Proveedor> ObtenerClientePorId(int contactoId);

        Task<int> ModificarProveedor(Proveedor contacto);
        Task EliminarProveedor(int id);
    }
}
