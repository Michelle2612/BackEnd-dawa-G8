﻿using BackEnd_Proyecto_Grupo_8.Entidades;
using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public class RepositorioProveedor : IRepositorioProveedor
    {
        private readonly ApplicationDbContext context;

        public RepositorioProveedor(ApplicationDbContext context)
        {
            this.context = context;
        }
        public async Task<int> AgregarProveedor(Proveedor proveedor)
        {
            context.Proveedores.Add(proveedor);
            await context.SaveChangesAsync();
            return proveedor.ProveedorId;
        }

        public async Task EliminarProveedor(int id)
        {
            Proveedor persona = await context.Proveedores.FindAsync(id);
            context.Proveedores.Remove(persona);
            context.SaveChanges();
        }

        public async Task<int> ModificarProveedor(Proveedor contacto)
        {
            Proveedor cli = await context.Proveedores.FindAsync(contacto.ProveedorId);
            cli.razon_social = contacto.razon_social;
            cli.RUC = contacto.RUC;
            cli.nombreProveedor = contacto.nombreProveedor;
            cli.correo = contacto.correo;
            cli.contrasenia = contacto.contrasenia;
            cli.correo = contacto.correo;
            cli.telefono = contacto.telefono;
            cli.direccion = contacto.direccion;
            cli.tipo = contacto.tipo;
            await context.SaveChangesAsync();
            return cli.ProveedorId;
        }

        public async Task<Proveedor> ObtenerClientePorId(int contactoId)
        {
            return await context.Proveedores.FindAsync(contactoId);
        }

        public  async Task<List<Proveedor>> ObtenerProveedor()
        {
            return await context.Proveedores.ToListAsync();
        }
    }
}
