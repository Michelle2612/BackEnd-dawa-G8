﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioCliente
    {
        Task<int> AgregarCliente(Cliente cliente);
        Task<List<Cliente>> ObtenerCliente();
        Task<Cliente> ObtenerClientePorId(int clienteId);

        Task<int> ModificarCliente(Cliente cliente);
        Task EliminarCliente(int id);
    }
}
