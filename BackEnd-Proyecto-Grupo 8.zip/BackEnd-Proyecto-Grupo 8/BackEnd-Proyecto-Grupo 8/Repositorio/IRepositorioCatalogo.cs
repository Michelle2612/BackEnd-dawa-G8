﻿using BackEnd_Proyecto_Grupo_8.Entidades;

namespace BackEnd_Proyecto_Grupo_8.Repositorio
{
    public interface IRepositorioCatalogo
    {
        Task<int> AgregarCatalogo(Catalogo catalogo);
        Task<List<Catalogo>> ObtenerCatalogo();
        Task<List<Catalogo>> ObtenerCatalogoPorCategoria(string categoria);
    }
}
