﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class reservasAS : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            /* migrationBuilder.AlterColumn<int>(
                 name: "clienteId",
                 table: "Reservaciones",
                 type: "integer",
                 nullable: false,
                 oldClrType: typeof(string),
                 oldType: "text");

             migrationBuilder.CreateIndex(
                 name: "IX_Reservaciones_clienteId",
                 table: "Reservaciones",
                 column: "clienteId");

             migrationBuilder.AddForeignKey(
                 name: "FK_Reservaciones_Clientes_clienteId",
                 table: "Reservaciones",
                 column: "clienteId",
                 principalTable: "Clientes",
                 principalColumn: "ClienteId",
                 onDelete: ReferentialAction.Cascade);*/
            migrationBuilder.Sql("ALTER TABLE \"Reservaciones\" ALTER COLUMN \"clienteId\" TYPE integer USING \"clienteId\"::integer");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            /*migrationBuilder.DropForeignKey(
                name: "FK_Reservaciones_Clientes_clienteId",
                table: "Reservaciones");

            migrationBuilder.DropIndex(
                name: "IX_Reservaciones_clienteId",
                table: "Reservaciones");

            migrationBuilder.AlterColumn<string>(
                name: "clienteId",
                table: "Reservaciones",
                type: "text",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");*/
            migrationBuilder.Sql("ALTER TABLE \"Reservaciones\" ALTER COLUMN \"clienteId\" TYPE <previous_type> USING \"clienteId\"::<previous_type>");
        }
    }
}
