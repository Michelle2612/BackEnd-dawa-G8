﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class productosActualizados : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdenPagos_Productos_productoId",
                table: "OrdenPagos");

            migrationBuilder.DropIndex(
                name: "IX_OrdenPagos_productoId",
                table: "OrdenPagos");

            migrationBuilder.DropColumn(
                name: "productoId",
                table: "OrdenPagos");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "productoId",
                table: "OrdenPagos",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_productoId",
                table: "OrdenPagos",
                column: "productoId");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdenPagos_Productos_productoId",
                table: "OrdenPagos",
                column: "productoId",
                principalTable: "Productos",
                principalColumn: "ProductoId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
