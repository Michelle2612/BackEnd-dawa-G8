﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class Inicio : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contactos",
                columns: table => new
                {
                    ContactoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    nombre = table.Column<string>(type: "text", nullable: false),
                    correo = table.Column<string>(type: "text", nullable: false),
                    asunto = table.Column<string>(type: "text", nullable: false),
                    descripcion = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contactos", x => x.ContactoId);
                });

            migrationBuilder.CreateTable(
                name: "Logins",
                columns: table => new
                {
                    LoginId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    usuario = table.Column<string>(type: "text", nullable: false),
                    contrasenia = table.Column<string>(type: "text", nullable: false),
                    tipoUsuario = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Logins", x => x.LoginId);
                });

            migrationBuilder.CreateTable(
                name: "Clientes",
                columns: table => new
                {
                    ClienteId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    nombreCliente = table.Column<string>(type: "text", nullable: false),
                    apellidoCliente = table.Column<string>(type: "text", nullable: false),
                    cedula = table.Column<int>(type: "integer", nullable: false),
                    direccion = table.Column<string>(type: "text", nullable: false),
                    fecha_nacimiento = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    genero = table.Column<string>(type: "text", nullable: false),
                    correo = table.Column<string>(type: "text", nullable: false),
                    contrasenia = table.Column<string>(type: "text", nullable: false),
                    telefono = table.Column<string>(type: "text", nullable: false),
                    loginId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clientes", x => x.ClienteId);
                    table.ForeignKey(
                        name: "FK_Clientes_Logins_loginId",
                        column: x => x.loginId,
                        principalTable: "Logins",
                        principalColumn: "LoginId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EmpresaTransportes",
                columns: table => new
                {
                    EmpresaTransporteId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    num_compania = table.Column<int>(type: "integer", nullable: false),
                    RUC = table.Column<int>(type: "integer", nullable: false),
                    nombreEmpresa = table.Column<string>(type: "text", nullable: false),
                    correo = table.Column<string>(type: "text", nullable: false),
                    contrasenia = table.Column<string>(type: "text", nullable: false),
                    telefono = table.Column<string>(type: "text", nullable: false),
                    direccion = table.Column<string>(type: "text", nullable: false),
                    loginId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmpresaTransportes", x => x.EmpresaTransporteId);
                    table.ForeignKey(
                        name: "FK_EmpresaTransportes_Logins_loginId",
                        column: x => x.loginId,
                        principalTable: "Logins",
                        principalColumn: "LoginId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Proveedores",
                columns: table => new
                {
                    ProveedorId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    razon_social = table.Column<int>(type: "integer", nullable: false),
                    RUC = table.Column<int>(type: "integer", nullable: false),
                    nombreProveedor = table.Column<string>(type: "text", nullable: false),
                    correo = table.Column<string>(type: "text", nullable: false),
                    contrasenia = table.Column<string>(type: "text", nullable: false),
                    telefono = table.Column<string>(type: "text", nullable: false),
                    direccion = table.Column<string>(type: "text", nullable: false),
                    tipo = table.Column<string>(type: "text", nullable: false),
                    loginId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Proveedores", x => x.ProveedorId);
                    table.ForeignKey(
                        name: "FK_Proveedores_Logins_loginId",
                        column: x => x.loginId,
                        principalTable: "Logins",
                        principalColumn: "LoginId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Productos",
                columns: table => new
                {
                    ProductoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    imagenProducto = table.Column<byte[]>(type: "bytea", nullable: false),
                    nombreProducto = table.Column<string>(type: "text", nullable: false),
                    cantidad = table.Column<int>(type: "integer", nullable: false),
                    precio = table.Column<decimal>(type: "numeric", nullable: false),
                    categoria = table.Column<string>(type: "text", nullable: false),
                    descripcion = table.Column<string>(type: "text", nullable: false),
                    proveedorId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productos", x => x.ProductoId);
                    table.ForeignKey(
                        name: "FK_Productos_Proveedores_proveedorId",
                        column: x => x.proveedorId,
                        principalTable: "Proveedores",
                        principalColumn: "ProveedorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Catalogos",
                columns: table => new
                {
                    CatalogoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    productoId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Catalogos", x => x.CatalogoId);
                    table.ForeignKey(
                        name: "FK_Catalogos_Productos_productoId",
                        column: x => x.productoId,
                        principalTable: "Productos",
                        principalColumn: "ProductoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Inventarios",
                columns: table => new
                {
                    InventarioId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    productoId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inventarios", x => x.InventarioId);
                    table.ForeignKey(
                        name: "FK_Inventarios_Productos_productoId",
                        column: x => x.productoId,
                        principalTable: "Productos",
                        principalColumn: "ProductoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrdenPagos",
                columns: table => new
                {
                    OrdenPagoId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    codigo = table.Column<int>(type: "integer", nullable: false),
                    clienteId = table.Column<int>(type: "integer", nullable: false),
                    proveedorId = table.Column<int>(type: "integer", nullable: false),
                    productoId = table.Column<int>(type: "integer", nullable: false),
                    empresaTransporteId = table.Column<int>(type: "integer", nullable: false),
                    metodoPago = table.Column<string>(type: "text", nullable: false),
                    total = table.Column<decimal>(type: "numeric", nullable: false),
                    subTotal = table.Column<decimal>(type: "numeric", nullable: false),
                    totalPagar = table.Column<decimal>(type: "numeric", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrdenPagos", x => x.OrdenPagoId);
                    table.ForeignKey(
                        name: "FK_OrdenPagos_Clientes_clienteId",
                        column: x => x.clienteId,
                        principalTable: "Clientes",
                        principalColumn: "ClienteId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrdenPagos_EmpresaTransportes_empresaTransporteId",
                        column: x => x.empresaTransporteId,
                        principalTable: "EmpresaTransportes",
                        principalColumn: "EmpresaTransporteId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrdenPagos_Productos_productoId",
                        column: x => x.productoId,
                        principalTable: "Productos",
                        principalColumn: "ProductoId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrdenPagos_Proveedores_proveedorId",
                        column: x => x.proveedorId,
                        principalTable: "Proveedores",
                        principalColumn: "ProveedorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reservaciones",
                columns: table => new
                {
                    ReservaId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    codigo = table.Column<int>(type: "integer", nullable: false),
                    clienteId = table.Column<int>(type: "integer", nullable: false),
                    productoId = table.Column<int>(type: "integer", nullable: false),
                    saldoTotal = table.Column<decimal>(type: "numeric", nullable: false),
                    saldoAbonado = table.Column<decimal>(type: "numeric", nullable: false),
                    total = table.Column<decimal>(type: "numeric", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservaciones", x => x.ReservaId);
                    table.ForeignKey(
                        name: "FK_Reservaciones_Clientes_clienteId",
                        column: x => x.clienteId,
                        principalTable: "Clientes",
                        principalColumn: "ClienteId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Reservaciones_Productos_productoId",
                        column: x => x.productoId,
                        principalTable: "Productos",
                        principalColumn: "ProductoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SolicitudOrdenes",
                columns: table => new
                {
                    SolicitudOrdenId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    codigo = table.Column<int>(type: "integer", nullable: false),
                    clienteId = table.Column<int>(type: "integer", nullable: false),
                    proveedorId = table.Column<int>(type: "integer", nullable: false),
                    productoId = table.Column<int>(type: "integer", nullable: false),
                    total = table.Column<decimal>(type: "numeric", nullable: false),
                    metodoPago = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SolicitudOrdenes", x => x.SolicitudOrdenId);
                    table.ForeignKey(
                        name: "FK_SolicitudOrdenes_Clientes_clienteId",
                        column: x => x.clienteId,
                        principalTable: "Clientes",
                        principalColumn: "ClienteId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SolicitudOrdenes_Productos_productoId",
                        column: x => x.productoId,
                        principalTable: "Productos",
                        principalColumn: "ProductoId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SolicitudOrdenes_Proveedores_proveedorId",
                        column: x => x.proveedorId,
                        principalTable: "Proveedores",
                        principalColumn: "ProveedorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Facturas",
                columns: table => new
                {
                    FacturaId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ordenPagoId = table.Column<int>(type: "integer", nullable: false),
                    fecha = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    razon_social = table.Column<int>(type: "integer", nullable: false),
                    ruc = table.Column<int>(type: "integer", nullable: false),
                    telefono = table.Column<string>(type: "text", nullable: false),
                    direccion = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Facturas", x => x.FacturaId);
                    table.ForeignKey(
                        name: "FK_Facturas_OrdenPagos_ordenPagoId",
                        column: x => x.ordenPagoId,
                        principalTable: "OrdenPagos",
                        principalColumn: "OrdenPagoId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Catalogos_productoId",
                table: "Catalogos",
                column: "productoId");

            migrationBuilder.CreateIndex(
                name: "IX_Clientes_loginId",
                table: "Clientes",
                column: "loginId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EmpresaTransportes_loginId",
                table: "EmpresaTransportes",
                column: "loginId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Facturas_ordenPagoId",
                table: "Facturas",
                column: "ordenPagoId");

            migrationBuilder.CreateIndex(
                name: "IX_Inventarios_productoId",
                table: "Inventarios",
                column: "productoId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_clienteId",
                table: "OrdenPagos",
                column: "clienteId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_empresaTransporteId",
                table: "OrdenPagos",
                column: "empresaTransporteId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_productoId",
                table: "OrdenPagos",
                column: "productoId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_proveedorId",
                table: "OrdenPagos",
                column: "proveedorId");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_proveedorId",
                table: "Productos",
                column: "proveedorId");

            migrationBuilder.CreateIndex(
                name: "IX_Proveedores_loginId",
                table: "Proveedores",
                column: "loginId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Reservaciones_clienteId",
                table: "Reservaciones",
                column: "clienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservaciones_productoId",
                table: "Reservaciones",
                column: "productoId");

            migrationBuilder.CreateIndex(
                name: "IX_SolicitudOrdenes_clienteId",
                table: "SolicitudOrdenes",
                column: "clienteId");

            migrationBuilder.CreateIndex(
                name: "IX_SolicitudOrdenes_productoId",
                table: "SolicitudOrdenes",
                column: "productoId");

            migrationBuilder.CreateIndex(
                name: "IX_SolicitudOrdenes_proveedorId",
                table: "SolicitudOrdenes",
                column: "proveedorId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Catalogos");

            migrationBuilder.DropTable(
                name: "Contactos");

            migrationBuilder.DropTable(
                name: "Facturas");

            migrationBuilder.DropTable(
                name: "Inventarios");

            migrationBuilder.DropTable(
                name: "Reservaciones");

            migrationBuilder.DropTable(
                name: "SolicitudOrdenes");

            migrationBuilder.DropTable(
                name: "OrdenPagos");

            migrationBuilder.DropTable(
                name: "Clientes");

            migrationBuilder.DropTable(
                name: "EmpresaTransportes");

            migrationBuilder.DropTable(
                name: "Productos");

            migrationBuilder.DropTable(
                name: "Proveedores");

            migrationBuilder.DropTable(
                name: "Logins");
        }
    }
}
