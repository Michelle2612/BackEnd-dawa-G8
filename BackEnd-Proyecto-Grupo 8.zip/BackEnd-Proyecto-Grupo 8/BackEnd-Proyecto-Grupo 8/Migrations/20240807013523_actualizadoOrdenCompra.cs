﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class actualizadoOrdenCompra : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdenPagos_Clientes_clienteId",
                table: "OrdenPagos");

            migrationBuilder.DropIndex(
                name: "IX_OrdenPagos_clienteId",
                table: "OrdenPagos");

            migrationBuilder.AlterColumn<string>(
                name: "clienteId",
                table: "OrdenPagos",
                type: "text",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "clienteId",
                table: "OrdenPagos",
                type: "integer",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_clienteId",
                table: "OrdenPagos",
                column: "clienteId");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdenPagos_Clientes_clienteId",
                table: "OrdenPagos",
                column: "clienteId",
                principalTable: "Clientes",
                principalColumn: "ClienteId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
