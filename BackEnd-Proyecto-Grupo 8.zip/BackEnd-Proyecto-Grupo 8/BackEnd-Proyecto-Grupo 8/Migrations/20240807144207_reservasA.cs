﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class reservasA : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Reservaciones_Clientes_clienteId",
                table: "Reservaciones");

            migrationBuilder.DropForeignKey(
                name: "FK_Reservaciones_Productos_productoId",
                table: "Reservaciones");

            migrationBuilder.DropIndex(
                name: "IX_Reservaciones_clienteId",
                table: "Reservaciones");

            migrationBuilder.DropIndex(
                name: "IX_Reservaciones_productoId",
                table: "Reservaciones");

            migrationBuilder.DropColumn(
                name: "productoId",
                table: "Reservaciones");

            migrationBuilder.AlterColumn<string>(
                name: "clienteId",
                table: "Reservaciones",
                type: "text",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "clienteId",
                table: "Reservaciones",
                type: "integer",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<int>(
                name: "productoId",
                table: "Reservaciones",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Reservaciones_clienteId",
                table: "Reservaciones",
                column: "clienteId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservaciones_productoId",
                table: "Reservaciones",
                column: "productoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Reservaciones_Clientes_clienteId",
                table: "Reservaciones",
                column: "clienteId",
                principalTable: "Clientes",
                principalColumn: "ClienteId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Reservaciones_Productos_productoId",
                table: "Reservaciones",
                column: "productoId",
                principalTable: "Productos",
                principalColumn: "ProductoId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
