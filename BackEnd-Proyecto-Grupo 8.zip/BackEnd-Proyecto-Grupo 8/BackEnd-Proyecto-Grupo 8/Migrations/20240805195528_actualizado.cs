﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BackEnd_Proyecto_Grupo_8.Migrations
{
    /// <inheritdoc />
    public partial class actualizado : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_OrdenPagos_Proveedores_proveedorId",
                table: "OrdenPagos");

            migrationBuilder.DropForeignKey(
                name: "FK_SolicitudOrdenes_Proveedores_proveedorId",
                table: "SolicitudOrdenes");

            migrationBuilder.DropIndex(
                name: "IX_SolicitudOrdenes_proveedorId",
                table: "SolicitudOrdenes");

            migrationBuilder.DropIndex(
                name: "IX_OrdenPagos_proveedorId",
                table: "OrdenPagos");

            migrationBuilder.DropColumn(
                name: "proveedorId",
                table: "SolicitudOrdenes");

            migrationBuilder.DropColumn(
                name: "proveedorId",
                table: "OrdenPagos");

            migrationBuilder.AlterColumn<string>(
                name: "imagenProducto",
                table: "Productos",
                type: "text",
                nullable: false,
                oldClrType: typeof(byte[]),
                oldType: "bytea");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "proveedorId",
                table: "SolicitudOrdenes",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<byte[]>(
                name: "imagenProducto",
                table: "Productos",
                type: "bytea",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "text");

            migrationBuilder.AddColumn<int>(
                name: "proveedorId",
                table: "OrdenPagos",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_SolicitudOrdenes_proveedorId",
                table: "SolicitudOrdenes",
                column: "proveedorId");

            migrationBuilder.CreateIndex(
                name: "IX_OrdenPagos_proveedorId",
                table: "OrdenPagos",
                column: "proveedorId");

            migrationBuilder.AddForeignKey(
                name: "FK_OrdenPagos_Proveedores_proveedorId",
                table: "OrdenPagos",
                column: "proveedorId",
                principalTable: "Proveedores",
                principalColumn: "ProveedorId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SolicitudOrdenes_Proveedores_proveedorId",
                table: "SolicitudOrdenes",
                column: "proveedorId",
                principalTable: "Proveedores",
                principalColumn: "ProveedorId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
