﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class EmpresaTransporte
    {
        public int EmpresaTransporteId { get; set; }
        public int num_compania { get; set; }
        public int RUC { get; set; }
        public string nombreEmpresa { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
        public string contrasenia { get; set; } = string.Empty;
        public string telefono { get; set; } = string.Empty;
        public string direccion { get; set; } = string.Empty;
        public int loginId { get; set; }
        public Login? Login { get; set; }

    }
}
