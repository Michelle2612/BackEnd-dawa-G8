﻿using System.Text.Json.Serialization;

namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public enum TipoUsuario
    {
        Cliente,
        Proveedor,
        EmpresaTransporte
    }
    public class Login
    {
        public int LoginId { get; set; }
        public string usuario { get; set; } = string.Empty;
        public string contrasenia { get; set; } = string.Empty;
        public string tipoUsuario { get; set; } = string.Empty;
        [JsonIgnore]
        public Cliente? Cliente { get; set; }
        [JsonIgnore]
        public Proveedor? Proveedor { get; set; }
        [JsonIgnore]
        public EmpresaTransporte? EmpresaTransporte { get; set; }
    }
}
