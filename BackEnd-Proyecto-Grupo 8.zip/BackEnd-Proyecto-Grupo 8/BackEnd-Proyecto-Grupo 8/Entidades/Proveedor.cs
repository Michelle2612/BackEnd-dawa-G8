﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Proveedor
    {
        public int ProveedorId { get; set; }
        public int razon_social { get; set; }
        public int RUC { get; set; }
        public string nombreProveedor { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
        public string contrasenia { get; set; } = string.Empty;
        public string telefono { get; set; } = string.Empty;
        public string direccion { get; set; } = string.Empty;
        public string tipo { get; set; } = string.Empty;
        public int loginId { get; set; }
        public Login? Login { get; set; }

    }
}
