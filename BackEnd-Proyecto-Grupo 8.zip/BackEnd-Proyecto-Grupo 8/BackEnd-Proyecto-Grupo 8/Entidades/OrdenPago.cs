﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class OrdenPago
    {
        public int OrdenPagoId { get; set; }
        public int codigo { get; set; }
        public string clienteId { get; set; } = string.Empty;
        public int empresaTransporteId { get; set; }
        public string metodoPago { get; set; } = string.Empty;
        public decimal total { get; set; }
        public decimal subTotal { get; set; }
        public decimal totalPagar { get; set; }
        public EmpresaTransporte? empresaTransporte { get; set; }
      
    }
}
