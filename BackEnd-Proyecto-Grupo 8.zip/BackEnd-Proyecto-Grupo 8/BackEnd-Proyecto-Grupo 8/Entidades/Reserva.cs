﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Reserva
    {
        public int ReservaId { get; set; }
        public int codigo { get; set; }
        public string clienteId { get; set; }
        public decimal saldoTotal { get; set; }
        public decimal saldoAbonado { get; set; }
        public decimal total { get; set; }

    }
}
