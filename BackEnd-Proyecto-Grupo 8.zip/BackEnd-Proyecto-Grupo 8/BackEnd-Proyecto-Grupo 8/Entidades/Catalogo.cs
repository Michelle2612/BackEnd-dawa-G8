﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Catalogo
    {
        public int CatalogoId { get; set; }

        public int productoId { get; set; }

        public Producto? producto { get; set; }
    }
}
