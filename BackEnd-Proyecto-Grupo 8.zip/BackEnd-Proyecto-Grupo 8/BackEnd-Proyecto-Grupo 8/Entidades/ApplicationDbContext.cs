﻿using Microsoft.EntityFrameworkCore;

namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    /*proyecto de STAR CLOTHING STORE (tienda de ropa)
      Grupo #8 */
    public class ApplicationDbContext : DbContext
    {
      public ApplicationDbContext(DbContextOptions options) : base(options){ }

     /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(@"Host=localhost;Database=STARCLOTHINGSTORE;Username=postgres;Password=12345");

        }*/
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Proveedor> Proveedores { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Catalogo> Catalogos { get; set; }
        public DbSet<Contacto> Contactos { get; set; }
        public DbSet<EmpresaTransporte> EmpresaTransportes { get; set; }
        public DbSet<Factura> Facturas { get; set; }
        public DbSet<Inventario> Inventarios { get; set; }
        public DbSet<OrdenPago> OrdenPagos { get; set; }
        public DbSet<Reserva> Reservaciones { get; set; }
        public DbSet<SolicitudOrden> SolicitudOrdenes { get; set; }
        public DbSet<Login> Logins { get; set; }
    }
}
