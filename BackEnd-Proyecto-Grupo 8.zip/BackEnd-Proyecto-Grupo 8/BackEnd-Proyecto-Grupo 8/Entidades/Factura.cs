﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Factura
    {
        public int FacturaId { get; set; }
        public int ordenPagoId { get; set; }

        public DateTime fecha { get; set; }
        public int razon_social { get; set; }
        public int ruc { get; set; }
        public string telefono { get; set; } = string.Empty;
        public string direccion { get; set; } = string.Empty;
        public OrdenPago? ordenPago { get; set; }
    }
}
