﻿using System.Text.Json.Serialization;

namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Cliente
    {
        public int ClienteId { get; set; }
        public string nombreCliente { get; set; } = string.Empty;
        public string apellidoCliente { get; set; } = string.Empty;
        public int cedula { get; set; }
        public string direccion { get; set; } = string.Empty;
        public DateTime fecha_nacimiento { get; set; }
        public string genero { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
        public string contrasenia { get; set; } = string.Empty;
        public string telefono { get; set; } = string.Empty;
        public int loginId { get; set; }
        [JsonIgnore]
        public Login? Login { get; set; }

    }
}
