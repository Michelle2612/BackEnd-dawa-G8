﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Inventario
    {
        public int InventarioId { get; set; }
        public int productoId { get; set; }
        public Producto? producto { get; set; }
    }
}
