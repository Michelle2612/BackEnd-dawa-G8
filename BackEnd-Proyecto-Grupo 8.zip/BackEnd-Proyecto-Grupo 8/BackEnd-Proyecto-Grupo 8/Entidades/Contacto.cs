﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Contacto
    {
        public int ContactoId { get; set; }
        public string nombre { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
        public string asunto { get; set; } = string.Empty;
        public string descripcion { get; set; } = string.Empty;
    }
}
