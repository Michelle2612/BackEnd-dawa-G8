﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class Producto
    {
        public int ProductoId { get; set; }
        public string imagenProducto { get; set; } = string.Empty;
        public string nombreProducto { get; set; } = string.Empty;
        public int cantidad { get; set; }
        public decimal precio { get; set; }
        public string categoria { get; set; } = string.Empty;
        public string descripcion { get; set; } = string.Empty;
        public int proveedorId { get; set; }

        public Proveedor? proveedor { get; set; }
    }
}
