﻿namespace BackEnd_Proyecto_Grupo_8.Entidades
{
    public class SolicitudOrden
    {
        public int SolicitudOrdenId { get; set; }
        public int codigo { get; set; }
        public int clienteId { get; set; }

        public int productoId { get; set; }
        public decimal total { get; set; }
        public string metodoPago { get; set; } = string.Empty;
        public Cliente? cliente { get; set; }

        public Producto? producto { get; set; }

    }
}
