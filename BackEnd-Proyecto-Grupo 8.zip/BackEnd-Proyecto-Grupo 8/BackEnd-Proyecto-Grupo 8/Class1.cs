﻿namespace BackEnd_Proyecto_Grupo_8
{
    public class Class1
    {

    }
}
